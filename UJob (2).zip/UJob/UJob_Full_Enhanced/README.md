# UJob Full (Android + API)

AndroidApp/ - Enhanced app with language, themes, resume, icons
SpringBootAPI/ - Spring Boot + MySQL

1. Run SpringBootAPI/database_setup.sql in MySQL
2. Open SpringBootAPI in IntelliJ, set password in application.properties, run
3. Open AndroidApp in Android Studio and run
