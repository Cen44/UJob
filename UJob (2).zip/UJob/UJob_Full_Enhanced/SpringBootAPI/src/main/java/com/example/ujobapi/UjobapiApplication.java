package com.example.ujobapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UjobapiApplication {
    public static void main(String[] args) {
        SpringApplication.run(UjobapiApplication.class, args);
    }
}
