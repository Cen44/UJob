CREATE DATABASE IF NOT EXISTS ujobdb;
USE ujobdb;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS opportunities (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    type VARCHAR(50),
    description TEXT,
    location VARCHAR(100),
    employer_name VARCHAR(150),
    no_experience_required BOOLEAN DEFAULT FALSE,
    verified BOOLEAN DEFAULT FALSE,
    closing_date VARCHAR(50),
    stipend VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS applications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    opportunity_id BIGINT,
    opportunity_title VARCHAR(200),
    status VARCHAR(50) DEFAULT 'APPLIED',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (opportunity_id) REFERENCES opportunities(id)
);

INSERT INTO opportunities (title, type, description, location, employer_name, no_experience_required, verified, closing_date, stipend) VALUES
('Retail Sales Assistant', 'JOB', 'Entry-level retail position. No experience needed.', 'Johannesburg', 'Pick n Pay', TRUE, TRUE, '2026-10-30', 'R4500'),
('Software Development Learnership', 'LEARNERSHIP', '12-month fully sponsored learnership with training.', 'Cape Town', 'Capaciti', TRUE, TRUE, '2026-09-30', 'R4500'),
('Warehouse Helper', 'JOB', 'General warehouse duties. Immediate start.', 'Durban', 'Imperial Logistics', TRUE, FALSE, '2026-11-15', 'R3800'),
('IT Support Internship', 'INTERNSHIP', '6-month internship for people with Matric.', 'Pretoria', 'TechSkills Academy', TRUE, TRUE, '2026-10-15', 'R3000'),
('Call Centre Agent', 'JOB', 'Customer service role. Training provided.', 'Johannesburg', 'Webhelp', TRUE, TRUE, '2026-10-20', 'R5200');
