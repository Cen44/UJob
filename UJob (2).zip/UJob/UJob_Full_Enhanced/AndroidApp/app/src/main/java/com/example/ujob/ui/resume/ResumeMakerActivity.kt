package com.example.ujob.ui.resume

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ujob.R
import com.example.ujob.data.local.AppPreferences
import com.example.ujob.databinding.ActivityResumeMakerBinding
import com.example.ujob.ui.theme.ThemeHelper

class ResumeMakerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResumeMakerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityResumeMakerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load saved resume fields
        binding.etFullName.setText(AppPreferences.getResumeField(this, "fullName"))
        binding.etEmail.setText(AppPreferences.getResumeField(this, "email").ifEmpty { AppPreferences.getUserEmail(this) })
        binding.etPhone.setText(AppPreferences.getResumeField(this, "phone"))
        binding.etEducation.setText(AppPreferences.getResumeField(this, "education"))
        binding.etExperience.setText(AppPreferences.getResumeField(this, "experience"))
        binding.etSkills.setText(AppPreferences.getResumeField(this, "skills"))
        binding.etSummary.setText(AppPreferences.getResumeField(this, "summary"))

        binding.btnSaveResume.setOnClickListener {
            val data = mapOf(
                "fullName" to binding.etFullName.text.toString().trim(),
                "email" to binding.etEmail.text.toString().trim(),
                "phone" to binding.etPhone.text.toString().trim(),
                "education" to binding.etEducation.text.toString().trim(),
                "experience" to binding.etExperience.text.toString().trim(),
                "skills" to binding.etSkills.text.toString().trim(),
                "summary" to binding.etSummary.text.toString().trim()
            )
            AppPreferences.saveResume(this, data)
            Toast.makeText(this, R.string.resume_saved, Toast.LENGTH_SHORT).show()
            updatePreview(data)
        }

        binding.btnBack.setOnClickListener { finish() }
        updatePreview(
            mapOf(
                "fullName" to binding.etFullName.text.toString(),
                "email" to binding.etEmail.text.toString(),
                "phone" to binding.etPhone.text.toString(),
                "education" to binding.etEducation.text.toString(),
                "experience" to binding.etExperience.text.toString(),
                "skills" to binding.etSkills.text.toString(),
                "summary" to binding.etSummary.text.toString()
            )
        )
    }

    private fun updatePreview(data: Map<String, String>) {
        binding.tvPreview.text = buildString {
            appendLine(data["fullName"].orEmpty())
            appendLine(data["email"].orEmpty())
            appendLine(data["phone"].orEmpty())
            appendLine()
            appendLine(getString(R.string.summary))
            appendLine(data["summary"].orEmpty())
            appendLine()
            appendLine(getString(R.string.education))
            appendLine(data["education"].orEmpty())
            appendLine()
            appendLine(getString(R.string.experience))
            appendLine(data["experience"].orEmpty())
            appendLine()
            appendLine(getString(R.string.skills))
            appendLine(data["skills"].orEmpty())
        }
    }
}
