package com.example.ujob.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ujob.data.model.Opportunity
import com.example.ujob.databinding.ItemOpportunityBinding

class OpportunityAdapter(private val onClick: (Opportunity) -> Unit) :
    RecyclerView.Adapter<OpportunityAdapter.VH>() {

    private var items = listOf<Opportunity>()

    fun submitList(list: List<Opportunity>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemOpportunityBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemOpportunityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.b.tvTitle.text = item.title
        holder.b.tvCompany.text = item.employerName
        holder.b.tvLocation.text = item.location
        holder.b.tvType.text = item.type
        holder.b.tvBadge.text = if (item.verified) "Verified ✓" else "New"
        holder.b.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size
}
