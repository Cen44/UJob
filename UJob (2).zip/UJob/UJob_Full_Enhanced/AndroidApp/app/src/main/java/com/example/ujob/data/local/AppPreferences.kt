package com.example.ujob.data.local

import android.content.Context
import android.content.SharedPreferences

object AppPreferences {
    private const val PREFS = "ujob_prefs"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isFirstLaunch(context: Context): Boolean =
        prefs(context).getBoolean("first_launch", true)

    fun setFirstLaunchDone(context: Context) {
        prefs(context).edit().putBoolean("first_launch", false).apply()
    }

    fun getLanguage(context: Context): String =
        prefs(context).getString("app_language", "en") ?: "en"

    fun setLanguage(context: Context, code: String) {
        prefs(context).edit().putString("app_language", code).apply()
    }

    fun getTheme(context: Context): String =
        prefs(context).getString("app_theme", "light") ?: "light"

    fun setTheme(context: Context, theme: String) {
        prefs(context).edit().putString("app_theme", theme).apply()
    }

    fun getUserId(context: Context): Long =
        prefs(context).getLong("user_id", -1)

    fun getUserEmail(context: Context): String =
        prefs(context).getString("user_email", "") ?: ""

    fun saveUser(context: Context, id: Long, email: String) {
        prefs(context).edit()
            .putLong("user_id", id)
            .putString("user_email", email)
            .apply()
    }

    fun clearUser(context: Context) {
        prefs(context).edit()
            .remove("user_id")
            .remove("user_email")
            .apply()
    }

    // Resume fields
    fun saveResume(context: Context, map: Map<String, String>) {
        val e = prefs(context).edit()
        map.forEach { (k, v) -> e.putString("resume_$k", v) }
        e.apply()
    }

    fun getResumeField(context: Context, key: String): String =
        prefs(context).getString("resume_$key", "") ?: ""
}
