package com.example.ujob.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ujob.R
import com.example.ujob.data.local.AppPreferences
import com.example.ujob.databinding.ActivitySettingsBinding
import com.example.ujob.ui.auth.LoginActivity
import com.example.ujob.ui.language.LanguageHelper
import com.example.ujob.ui.theme.ThemeHelper

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvEmail.text = AppPreferences.getUserEmail(this)

        // Language
        val langLabels = LanguageHelper.languages.map { it.second }
        binding.spinnerLanguage.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langLabels)
        val currentLang = AppPreferences.getLanguage(this)
        binding.spinnerLanguage.setSelection(LanguageHelper.languages.indexOfFirst { it.first == currentLang }.coerceAtLeast(0))

        // Theme
        val themeLabels = ThemeHelper.themes.map { it.second }
        binding.spinnerTheme.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themeLabels)
        val currentTheme = AppPreferences.getTheme(this)
        binding.spinnerTheme.setSelection(ThemeHelper.themes.indexOfFirst { it.first == currentTheme }.coerceAtLeast(0))

        binding.btnSavePrefs.setOnClickListener {
            val lang = LanguageHelper.languages[binding.spinnerLanguage.selectedItemPosition].first
            val theme = ThemeHelper.themes[binding.spinnerTheme.selectedItemPosition].first
            LanguageHelper.setLanguage(this, lang)
            ThemeHelper.setTheme(this, theme)
            Toast.makeText(this, R.string.preferences_saved, Toast.LENGTH_SHORT).show()
            // Recreate to apply theme immediately
            recreate()
        }

        binding.btnLogout.setOnClickListener {
            AppPreferences.clearUser(this)
            Toast.makeText(this, R.string.logged_out, Toast.LENGTH_SHORT).show()
            val i = Intent(this, LoginActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            finish()
        }

        binding.btnBack.setOnClickListener { finish() }
    }
}
