package com.example.ujob.ui.applications

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ujob.R
import com.example.ujob.data.api.RetrofitClient
import com.example.ujob.data.local.AppPreferences
import com.example.ujob.data.model.Application
import com.example.ujob.databinding.ActivityApplicationsBinding
import com.example.ujob.databinding.ItemApplicationBinding
import com.example.ujob.ui.theme.ThemeHelper
import kotlinx.coroutines.launch

class ApplicationsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApplicationsBinding
    private lateinit var adapter: ApplicationsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityApplicationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ApplicationsAdapter()
        binding.rvApplications.layoutManager = LinearLayoutManager(this)
        binding.rvApplications.adapter = adapter
        binding.btnBack.setOnClickListener { finish() }

        val userId = AppPreferences.getUserId(this)
        if (userId == -1L) {
            Toast.makeText(this, R.string.please_login, Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                adapter.submitList(RetrofitClient.api.getMyApplications(userId))
            } catch (e: Exception) {
                Toast.makeText(this@ApplicationsActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }
}

class ApplicationsAdapter : androidx.recyclerview.widget.RecyclerView.Adapter<ApplicationsAdapter.VH>() {
    private var items = listOf<Application>()
    fun submitList(list: List<Application>) { items = list; notifyDataSetChanged() }
    inner class VH(val b: ItemApplicationBinding) : androidx.recyclerview.widget.RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(p: android.view.ViewGroup, v: Int) =
        VH(ItemApplicationBinding.inflate(android.view.LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) {
        h.b.tvTitle.text = items[pos].opportunityTitle
        h.b.tvStatus.text = items[pos].status
    }
    override fun getItemCount() = items.size
}
