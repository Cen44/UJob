package com.example.ujob.ui.language

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.example.ujob.data.local.AppPreferences

object LanguageHelper {
    val languages = listOf(
        "en" to "English",
        "zu" to "isiZulu",
        "af" to "Afrikaans",
        "xh" to "isiXhosa"
    )

    fun applySavedLanguage(context: Context) {
        val code = AppPreferences.getLanguage(context)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
    }

    fun setLanguage(context: Context, code: String) {
        AppPreferences.setLanguage(context, code)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
    }
}
