package com.example.ujob.data.api

import com.example.ujob.data.model.Application
import com.example.ujob.data.model.Opportunity
import com.example.ujob.data.model.User
import retrofit2.http.*

interface ApiService {
    @POST("api/auth/register")
    suspend fun register(@Body user: User): Map<String, Any>

    @POST("api/auth/login")
    suspend fun login(@Body user: User): Map<String, Any>

    @GET("api/opportunities")
    suspend fun getOpportunities(): List<Opportunity>

    @POST("api/applications")
    suspend fun apply(@Body application: Application): Application

    @GET("api/applications/user/{userId}")
    suspend fun getMyApplications(@Path("userId") userId: Long): List<Application>
}
