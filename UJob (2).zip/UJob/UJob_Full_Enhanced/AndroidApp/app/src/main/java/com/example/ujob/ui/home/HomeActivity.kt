package com.example.ujob.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ujob.R
import com.example.ujob.data.api.RetrofitClient
import com.example.ujob.databinding.ActivityHomeBinding
import com.example.ujob.ui.applications.ApplicationsActivity
import com.example.ujob.ui.detail.OpportunityDetailActivity
import com.example.ujob.ui.resume.ResumeMakerActivity
import com.example.ujob.ui.settings.SettingsActivity
import com.example.ujob.ui.theme.ThemeHelper
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var adapter: OpportunityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = OpportunityAdapter { opp ->
            val i = Intent(this, OpportunityDetailActivity::class.java)
            i.putExtra("id", opp.id)
            i.putExtra("title", opp.title)
            i.putExtra("description", opp.description)
            i.putExtra("location", opp.location)
            i.putExtra("type", opp.type)
            i.putExtra("verified", opp.verified)
            i.putExtra("noExp", opp.noExperienceRequired)
            i.putExtra("employerName", opp.employerName)
            startActivity(i)
        }
        binding.rvOpportunities.layoutManager = LinearLayoutManager(this)
        binding.rvOpportunities.adapter = adapter

        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnApplications.setOnClickListener { startActivity(Intent(this, ApplicationsActivity::class.java)) }
        binding.btnResume.setOnClickListener { startActivity(Intent(this, ResumeMakerActivity::class.java)) }

        loadOpportunities()
    }

    private fun loadOpportunities() {
        lifecycleScope.launch {
            try {
                adapter.submitList(RetrofitClient.api.getOpportunities())
            } catch (e: Exception) {
                Toast.makeText(this@HomeActivity, getString(R.string.load_jobs_failed, e.message), Toast.LENGTH_LONG).show()
            }
        }
    }
}
