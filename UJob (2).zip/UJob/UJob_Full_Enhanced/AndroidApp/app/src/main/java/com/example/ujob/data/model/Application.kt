package com.example.ujob.data.model

data class Application(
    val id: Long? = null,
    val userId: Long,
    val opportunityId: Long,
    val opportunityTitle: String,
    val status: String = "APPLIED"
)
