package com.example.ujob.ui.detail

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.ujob.R
import com.example.ujob.data.api.RetrofitClient
import com.example.ujob.data.local.AppPreferences
import com.example.ujob.data.model.Application
import com.example.ujob.databinding.ActivityOpportunityDetailBinding
import com.example.ujob.ui.theme.ThemeHelper
import kotlinx.coroutines.launch

class OpportunityDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOpportunityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityOpportunityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getLongExtra("id", 0)
        val title = intent.getStringExtra("title") ?: ""
        binding.tvTitle.text = title
        binding.tvCompany.text = intent.getStringExtra("employerName") ?: ""
        binding.tvLocation.text = intent.getStringExtra("location") ?: ""
        binding.tvType.text = intent.getStringExtra("type") ?: ""
        binding.tvDescription.text = intent.getStringExtra("description") ?: ""
        binding.tvVerified.text = if (intent.getBooleanExtra("verified", false)) getString(R.string.verified_employer) else getString(R.string.not_verified)
        binding.tvNoExp.text = if (intent.getBooleanExtra("noExp", false)) getString(R.string.no_experience) else getString(R.string.experience_may_be_required)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnApply.setOnClickListener {
            val userId = AppPreferences.getUserId(this)
            if (userId == -1L) {
                Toast.makeText(this, R.string.please_login, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                try {
                    RetrofitClient.api.apply(Application(userId = userId, opportunityId = id, opportunityTitle = title))
                    Toast.makeText(this@OpportunityDetailActivity, R.string.application_submitted, Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@OpportunityDetailActivity, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
