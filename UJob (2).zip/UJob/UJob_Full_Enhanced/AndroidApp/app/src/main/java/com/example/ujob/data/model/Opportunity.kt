package com.example.ujob.data.model

data class Opportunity(
    val id: Long,
    val title: String,
    val type: String,
    val description: String,
    val location: String,
    val employerName: String,
    val noExperienceRequired: Boolean,
    val verified: Boolean,
    val closingDate: String?,
    val stipend: String?
)
