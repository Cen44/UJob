package com.example.ujob.ui.language

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.ujob.data.local.AppPreferences
import com.example.ujob.databinding.ActivityWelcomeBinding
import com.example.ujob.ui.auth.LoginActivity
import com.example.ujob.ui.theme.ThemeHelper

/**
 * Shown on first launch before Login.
 * User picks language and theme, then continues.
 */
class WelcomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding
    private var selectedLanguage = "en"
    private var selectedTheme = "light"

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)

        // If not first launch, skip straight to login
        if (!AppPreferences.isFirstLaunch(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Language spinner
        val langLabels = LanguageHelper.languages.map { it.second }
        binding.spinnerLanguage.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langLabels)
        binding.spinnerLanguage.setSelection(0)

        // Theme spinner
        val themeLabels = ThemeHelper.themes.map { it.second }
        binding.spinnerTheme.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themeLabels)
        binding.spinnerTheme.setSelection(0)

        binding.btnContinue.setOnClickListener {
            selectedLanguage = LanguageHelper.languages[binding.spinnerLanguage.selectedItemPosition].first
            selectedTheme = ThemeHelper.themes[binding.spinnerTheme.selectedItemPosition].first

            LanguageHelper.setLanguage(this, selectedLanguage)
            ThemeHelper.setTheme(this, selectedTheme)
            AppPreferences.setFirstLaunchDone(this)

            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
