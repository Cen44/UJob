package com.example.ujob.ui.theme

import android.app.Activity
import android.content.Context
import com.example.ujob.R
import com.example.ujob.data.local.AppPreferences

object ThemeHelper {
    val themes = listOf(
        "light" to "Light",
        "dark" to "Dark",
        "blue" to "Blue",
        "green" to "Green"
    )

    fun applyTheme(activity: Activity) {
        val theme = AppPreferences.getTheme(activity)
        val style = when (theme) {
            "dark" -> R.style.Theme_Ujob_Dark
            "blue" -> R.style.Theme_Ujob_Blue
            "green" -> R.style.Theme_Ujob_Green
            else -> R.style.Theme_Ujob_Light
        }
        activity.setTheme(style)
    }

    fun setTheme(context: Context, themeKey: String) {
        AppPreferences.setTheme(context, themeKey)
    }
}
