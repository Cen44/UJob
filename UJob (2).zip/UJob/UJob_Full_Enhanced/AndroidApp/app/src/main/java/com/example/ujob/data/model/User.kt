package com.example.ujob.data.model

data class User(
    val id: Long? = null,
    val email: String,
    val password: String,
    val fullName: String? = null,
    val phone: String? = null
)
