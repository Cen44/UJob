# UJob Enhanced – Android App

## New features added
1. **Multi-language first-launch screen** (English, isiZulu, Afrikaans, isiXhosa)
2. **Theme customisation** (Light, Dark, Blue, Green) – choose on first launch and change anytime in Settings
3. **Resume Maker** – build and save a simple CV (name, contact, summary, education, experience, skills) with live preview
4. Full layouts and string resources (group ZIP was missing the entire `res` folder)

## How to open
1. Open this folder in Android Studio
2. Let Gradle sync
3. Make sure your Spring Boot API is running
4. Run on emulator (API base URL is `http://10.0.2.2:8080/`)

## First launch flow
Welcome screen → pick language + theme → Continue → Login / Register → Home

## Screens
- Welcome (language + theme)
- Login / Register
- Home (job list)
- Opportunity Detail (Apply)
- My Applications
- Resume Maker
- Settings (language, theme, logout)

## Change API URL for real phone
Edit `app/src/main/java/com/example/ujob/data/api/RetrofitClient.kt`:
```kotlin
private const val BASE_URL = "http://YOUR_LAPTOP_IP:8080/"
```
